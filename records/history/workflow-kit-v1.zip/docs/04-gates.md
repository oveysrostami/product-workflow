# دروازه‌های عبور و تعریف پایان

gate صرفاً رأی نیست؛ هم شرایط قابل بررسی و هم مسئول انسانی دارد. `approved-with-risk` فقط برای ریسک باقیماندهٔ غیرمسدودکننده با owner و موعد معتبر است. ابهام رفتار در scope، نقض authorization/حریم خصوصی، تست بحرانی اجرا‌نشده و capability لازمِ unavailable با waiver عمومی پاس نمی‌شوند.

| Gate | ورودی لازم | شرط عبور | مسئول انسانی | مسیر رد |
|---|---|---|---|---|
| G-P محصول | قرارداد، UC/AC، decisions، review و manifest | رفتار و خطا/تکرار روشن؛ تمام open itemهای مؤثر بسته یا صریح از scope خارج؛ پنهان‌بودن رفتار در ضمیمه وجود ندارد | همان درخواست‌کننده | P02 برای تصمیم؛ P04 برای نگارش |
| G-Q طراحی QA | G-P و receipt، plan/scenarios/coverage | همهٔ rule/ACهای scope پوشش و oracle مستقل دارند؛ risk/N/A مستدل؛ فرض فنی جای oracle نیست | QA owner | Q02/Q03؛ gap محصول از C01 |
| G-T طراحی فنی | baseline محصول و QA معتبر؛ طرح ownerها و test mapping | قرارداد/DTO، authorization، داده/اثر/uncertainty، migration و capability لازم قابل اجرا؛ taskها و evidence plan روشن | Tech lead؛ QA owner برای testability | T02–T05 یا C01 |
| G-D تحویل | candidate revision، code review، evidence واقعی و QA execution | blocker صفر؛ تست‌های لازم pass بدون skip پنهان؛ اسناد هم‌نسخه؛ acceptance و محدودیت روشن | Tech lead برای کد، QA owner برای کیفیت، درخواست‌کننده برای تحقق scope | D02/T02/C01 متناسب با علت |
| G-R انتشار اختیاری | G-D، release manifest و runbook | اختیار صریح merge/deploy برای target، current-run full evidence و prerequisiteهای عملیاتی | Release owner | R01 یا D06؛ بدون اختیار توقف |

تأییدهای یک gate می‌توانند در یک پیام یا جلسه جمع شوند، اما پاسخ، نقش و digest هر تصمیم جدا ثبت می‌شود. دریافت بسته توسط مسئول مرحلهٔ بعد در همان جلسه قابل ثبت است؛ نیازی به جلسهٔ اداری اضافی نیست.

## بازبینی قبل از درخواست تأیید

AI باید بستهٔ کامل، خلاصهٔ تغییر، لینک سند اصلی، موارد باز، نتیجهٔ validation و manifest را آماده کند. از انسان نخواهد «اجازه بده شروع کنم» وقتی تهیهٔ پیش‌نویس در scope درخواست است. درخواست تأیید باید تصمیم روی نسخهٔ قابل مشاهده باشد.

## طبقه‌بندی یافته

- **blocking:** نتیجهٔ غلط، rule بی‌شاهد، مرز اعتماد/داده شکسته، تست لازم غایب، طراحی غیرقابل اجرا یا evidence نامعتبر. عبور gate متوقف است.
- **major:** نقص مهم پوشش/وضوح/نگهداری. پیش از gate رفع شود، مگر owner مربوط با دلیل اثبات کند خارج scope همان gate است.
- **minor:** بهبود نگارش یا مسئلهٔ غیرمؤثر بر رفتار؛ می‌تواند با owner و موعد ثبت شود.

شدت فنی defect با اولویت تجاری متفاوت است. کاهش priority، blocker را پاک نمی‌کند. AI یافته را با محل، شاهد، اثر، پیشنهاد اصلاح و node برگشت ثبت می‌کند.

## Definition of Done

خواستهٔ همین scope پیاده شده؛ هر AC شاهد دارد؛ معماری و تست واقعی متناسب پاس‌اند؛ review مستقل و پذیرش انسانی ثبت‌اند؛ consumer/migration/operations contractهای مرتبط به‌روزند؛ recipient دریافت کرده؛ کار باقی‌مانده و حدود evidence روشن است. «کد آمادهٔ merge»، «merged»، «deployed» و «پذیرفته‌شده در production» برچسب‌های جدا هستند و فقط با شاهد همان عمل ثبت می‌شوند.
