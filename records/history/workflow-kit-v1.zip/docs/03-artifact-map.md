# ساختار و مرجع اسناد

```text
requests/<request-id>/
  request.md                  # شرح و routing، stakeholder و owner
  decisions.md                # تصمیم، منبع، open item و تاریخچه
  interview.md                # متن کامل batch و پاسخ‌های پالایش‌شده
  applicability.md            # اسناد لازم/نامرتبط با دلیل
  traceability.csv            # RULE → UC → AC → QA → TECH → TASK → EVIDENCE
  product/                    # رفتار محصول و handover به QA
  qa/                         # strategy، سناریو، coverage و handover به فنی
  technical/                  # طراحی cross-owner و index اسناد canonical backend
  development/                # taskها، review، execution و delivery
  baselines/                  # manifestهای immutable هر مرحله
  approvals/                  # تصمیم‌های انسانی append-only
  receipts/                   # اعلام دریافت بسته
  reviews/                    # یافته‌ها و حل آن‌ها
  runs/                       # journal nodeها و evidence امن
  changes/                    # تغییر scope، نسخه یا defect مرتبط
```

برای backend مستند فنی owner در `backend/modules/<owner>/docs/` مرجع نهایی است؛ `technical/index.md` در پرونده فقط لینک، revision، hash و تصمیم cross-owner دارد. در مرحلهٔ طراحی، draftها می‌توانند در همان branch مستندات Backend باشند. اگر دسترسی نوشتن نیست، candidate در پرونده با مقصد دقیق آماده می‌شود؛ T06 پیش از تحویل canonical location را مشخص می‌کند و دو نسخهٔ editable مرجع نمی‌ماند.

## حداقل بسته و توسعهٔ مشروط

| مرحله | همیشه لازم | فقط در صورت ارتباط |
|---|---|---|
| مشترک | request، decisions، applicability، traceability، manifest، approval و receipt مرحله | interview اگر سؤال، impact اگر تغییر، finding اگر review نقص دارد |
| محصول | contract، شرح مستقل UC/operation، acceptance، handover | flows برای lifecycle/شاخه، data برای داده، تعاملات برای وابستگی؛ N/A صریح در applicability |
| QA | plan، scenarioهای دارای oracle، coverage، handover | performance/security/recovery/migration برای ریسک موجود؛ UI در صورت وجود کلاینت |
| فنی | index، module/context، operation/DTO، test mapping و implementation plan، handover | domain، data/migration، communication/message، recording، deployment/ADR متناسب با اثر |
| توسعه | task، execution evidence، review، delivery و receipt | bug record، release/rollback در scope انتشار |

«نامرتبط» برای موضوع است، نه رفع الزام با فایل کوتاه. یک query بدون state به aggregate مصنوعی نیاز ندارد، اما authorization، DTO، bounded query و failure لازم دارد. اسناد کوچک را می‌توان در فایل واحد با section و ID مستقل نوشت؛ handover و approval همیشه مستقل و قابل پیدا کردن‌اند.

## تفکیک محصول از فنی

| مفهوم | محصول | فنی |
|---|---|---|
| داده | دلیل جمع‌آوری، دسترسی، عمر، حذف و رابطهٔ مفهومی | schema، SQL type، index، JPA، transaction و migration |
| عملیات | actor، input/output معنایی، مراحل، خطا و تکرار قابل مشاهده | signature، HTTP/status/schema، port و error mapping |
| هم‌زمانی | کدام نتیجه مجاز است و چه چیزی نباید دوبار رخ دهد | version، lock، receipt و atomicity |
| رویداد | چه واقعیت قطعی برای چه مصرف‌کننده لازم است | envelope، Outbox/Inbox، version، retry و DLQ/quarantine |
| پذیرش | مثال‌های نتیجهٔ مطلوب و ممنوع | QA روش سنجش؛ فنی مکان تست؛ توسعه evidence اجرا |

## قواعد traceability

هر rule پذیرفته‌شده حداقل یک UC و AC دارد. هر AC در scope حداقل یک QA scenario دارد. هر QA scenario یا test/evidence دارد یا وضعیت `not-run/blocked` با دلیل؛ حذف ردیف مجاز نیست. هر task به TECH و QA/AC متصل است. هر الزام صرفاً معماری می‌تواند `source=backend-rule` داشته باشد و نیاز به ساخت rule محصول جعلی ندارد. رابطه‌ها چندبه‌چندند؛ یک ردیف برای هر مسیر پوشش ثبت کنید و IDها را مستقل از شمارهٔ خط نگه دارید.

در پروندهٔ چندماژولی یک قرارداد مشترک و یک traceability اصلی نگه دارید؛ owner هر قاعده و اثر بر مصرف‌کننده مشخص باشد. تحویل یک owner قبل از dependency لازم فقط به‌عنوان slice مستقل با پذیرش مستقل مجاز است.
