#!/usr/bin/env python3
"""Check this documentation kit. Does not certify approvals or backend behavior."""
import csv
import hashlib
import json
import re
import sys
from pathlib import Path
from urllib.parse import unquote, urlsplit
from render_workflows import documents
ROOT = Path(__file__).resolve().parents[1]
errors = []
stats = {'markdownFiles': 0, 'localLinks': 0, 'diagrams': 0, 'nodes': 0, 'walkthroughs': 0}

def fail(message):
    errors.append(message)

def check_graph():
    g = json.loads((ROOT/'workflows/graph.json').read_text())
    nodes = {}
    for f in g['workflows']:
        for n in f['nodes']:
            if n['id'] in nodes:
                fail('Duplicate node: '+n['id'])
            nodes[n['id']] = n
            for key in ('id','title','actor','role','inputs','action','outputs','done','transitions'):
                if not n.get(key):
                    fail(f"Missing {key}: {n.get('id')}")
            if n['actor'] not in ('AI','Human','Tool'):
                fail('Invalid actor: '+n['id'])
            if len({t['condition'] for t in n['transitions']}) != len(n['transitions']):
                fail('Ambiguous identical conditions: '+n['id'])
    for n in nodes.values():
        for t in n['transitions']:
            if not t.get('condition') or t['target'] not in nodes and t['target'] not in g['terminals']:
                fail(f"Invalid transition: {n['id']} -> {t}")
    seen, todo = set(), [g['entry']]
    while todo:
        id = todo.pop()
        if id in seen or id in g['terminals']:
            continue
        seen.add(id)
        if id in nodes:
            todo.extend(t['target'] for t in nodes[id]['transitions'])
    for missing in set(nodes)-seen:
        fail('Unreachable node: '+missing)
    # Each node must have at least one possible route to an explicit terminal.
    reaching = set(g['terminals'])
    while True:
        new = {id for id,n in nodes.items() if any(t['target'] in reaching for t in n['transitions'])}
        if new <= reaching:
            break
        reaching |= new
    for id in set(nodes)-reaching:
        fail('No terminal route: '+id)
    for path, expected in documents(g).items():
        p = ROOT/path
        if not p.exists() or p.read_text() != expected:
            fail('Cards out of sync; run render_workflows.py: '+path)
    stats['nodes'] = len(nodes)
    # Walkthrough paths are documentation regression cases, not runtime simulations.
    for line in (ROOT/'examples/otp-issue/walkthroughs.md').read_text().splitlines():
        if '→' not in line:
            continue
        path = re.findall(r'\b(?:[IPQTDVCBR]\d{2}|END|HOLD)\b',line)
        if len(path) < 2:
            continue
        stats['walkthroughs'] += 1
        for a,b in zip(path,path[1:]):
            if a not in nodes or b not in {t['target'] for t in nodes[a]['transitions']}:
                fail(f'Walkthrough edge absent: {a} -> {b}')
    return g

def slug(s):
    s = re.sub(r'[^\w\-\s]', '', s.lower()).strip()
    return re.sub(r'\s', '-', s)

def check_markdown():
    for path in sorted(ROOT.rglob('*.md')):
        stats['markdownFiles'] += 1
        s = path.read_text()
        fences = re.findall(r'^```.*$',s,re.M)
        if len(fences)%2:
            fail(f'Unbalanced fences: {path.relative_to(ROOT)}')
        stats['diagrams'] += len(re.findall(r'^```mermaid\s*$',s,re.M))
        # Ignore fenced code where links and placeholders are literal examples.
        prose = re.sub(r'```[^\n]*\n[\s\S]*?```', '', s)
        for target in re.findall(r'(?<!!)\[[^\]\n]*\]\(([^)\n]+)\)',prose):
            target = target.strip().strip('<>')
            if '{{' in target:
                continue
            u = urlsplit(target)
            if u.scheme or target.startswith('//'):
                continue
            resolved = (path.parent/unquote(u.path)).resolve() if u.path else path
            stats['localLinks'] += 1
            if not resolved.exists():
                fail(f'Broken link {path.relative_to(ROOT)}: {target}')
            elif u.fragment and resolved.is_file() and resolved.suffix == '.md':
                text = resolved.read_text()
                anchors = set(re.findall(r'<a id="([^"]+)"',text))
                anchors |= {slug(h) for h in re.findall(r'^#{1,6}\s+(.+)',text,re.M)}
                if unquote(u.fragment) not in anchors:
                    fail(f'Missing anchor {path.relative_to(ROOT)}: {target}')
        if 'templates' not in path.relative_to(ROOT).parts and re.search(r'\{\{[^}]+\}\}',prose):
            fail(f'Template placeholder outside template: {path.relative_to(ROOT)}')

def check_json_and_templates():
    for path in ROOT.rglob('*.json'):
        try:
            json.loads(path.read_text())
        except (ValueError,UnicodeError) as exc:
            fail(f'Invalid JSON: {path.relative_to(ROOT)}: {exc}')
    for name in ('approval','manifest','receipt','node-run'):
        data=json.loads((ROOT/f'templates/shared/{name}.json').read_text())
        if data.get('schemaVersion') != 1:
            fail('Invalid template schemaVersion: '+name)
    with (ROOT/'templates/shared/traceability.csv').open() as f:
        rows=list(csv.reader(f))
    if not rows or any(len(row)!=len(rows[0]) for row in rows):
        fail('Malformed traceability CSV')
    # The design kit itself must never imply an unreceived human approval.
    approval=ROOT/'records/design-approval.json'
    if approval.exists():
        d=json.loads(approval.read_text())
        if d.get('status')=='approved' and not d.get('decisions'):
            fail('Design approved without a recorded human decision')

def check_design_baseline():
    path = ROOT/'records/design-manifest.json'
    if not path.exists():
        return
    manifest = json.loads(path.read_text())
    for item in manifest['artifacts']:
        file = (ROOT/item['path']).resolve()
        if not file.is_relative_to(ROOT) or not file.is_file():
            fail('Invalid design baseline path: '+item['path'])
        elif hashlib.sha256(file.read_bytes()).hexdigest() != item['sha256']:
            fail('Design baseline changed: '+item['path'])
    approval = json.loads((ROOT/'records/design-approval.json').read_text())
    if approval.get('manifestSha256') != hashlib.sha256(path.read_bytes()).hexdigest():
        fail('Design approval references a different manifest digest')

def main():
    try:
        check_graph();check_markdown();check_json_and_templates();check_design_baseline()
    except (KeyError,ValueError,OSError) as exc:
        fail(str(exc))
    print(json.dumps({'status':'failed' if errors else 'passed','checks':stats,'errors':errors,'scope':'links, anchors, graph, generated cards, walkthrough edges, syntax of JSON/CSV and design baseline hashes; Mermaid must be checked separately'},ensure_ascii=False,indent=2))
    return 1 if errors else 0

if __name__ == '__main__':
    sys.exit(main())
