#!/usr/bin/env python3
"""Render readable node cards from the local workflow specification; no execution."""
import argparse
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

def documents(graph):
    location = {n['id']: f['id'] for f in graph['workflows'] for n in f['nodes']}
    result = {}
    for flow in graph['workflows']:
        lines = [f"# {flow['title']}", '', flow['description'], '',
                 '> کارت‌ها از [graph.json](graph.json) تولید می‌شوند. توقف، انتظار و retry مشترک در [قرارداد node](00-node-contract.md) اعمال می‌شود.', '',
                 '```mermaid', 'flowchart TD']
        local = {n['id'] for n in flow['nodes']}
        external = set()
        for n in flow['nodes']:
            lines.append(f'    {n["id"]}["{n["id"]} · {n["actor"]} · {n["title"]}"]')
            external.update(t['target'] for t in n['transitions'] if t['target'] not in local)
        for target in sorted(external):
            lines.append(f'    {target}["{target} · ادامه در مسیر مربوط"]')
        for n in flow['nodes']:
            for t in n['transitions']:
                lines.append(f'    {n["id"]} -->|"{t["condition"]}"| {t["target"]}')
        lines += ['```', '']
        for n in flow['nodes']:
            lines += [f'<a id="{n["id"].lower()}"></a>', f'## {n["id"]} — {n["title"]}', '',
                      f'**مجری:** {n["actor"]} — {n["role"]}', '',
                      f'**ورودی:** {n["inputs"]}', '', f'**کار دقیق:** {n["action"]}', '',
                      f'**خروجی:** {n["outputs"]}', '', f'**شرط پایان:** {n["done"]}', '',
                      '| نتیجه | node بعدی |', '|---|---|']
            for t in n['transitions']:
                target = t['target']
                link = target if target in graph['terminals'] else f'[{target}]({location[target]}.md#{target.lower()})'
                lines.append(f'| {t["condition"]} | {link} |')
            lines += ['']
        result[f'workflows/{flow["id"]}.md'] = '\n'.join(lines).rstrip() + '\n'
    lines = ['# نقشهٔ workflowها و nodeها', '',
             'شروع هر درخواست واقعی **I01** است. چهار gate اصلی G-P، G-Q، G-T و G-D طبق [معیارها](../docs/04-gates.md) اجرا می‌شوند؛ G-R فقط برای انتشار خواسته‌شده است.', '',
             'قرارداد ورودی/خروجی و توقف همهٔ nodeها در [00](00-node-contract.md) مشترک است. شاخه‌های شکست، نقص و بازگشت در کارت همان node آمده‌اند. مسیر مستقیم تا پیاده‌سازی فقط وقتی مجاز است که baselineهای معتبر پیشین وجود داشته باشند.', '',
             '| workflow | nodeها | ورودی → خروجی |', '|---|---|---|']
    for f in graph['workflows']:
        lines.append(f'| [{f["title"]}]({f["id"]}.md) | {f["nodes"][0]["id"]} تا {f["nodes"][-1]["id"]} | {f["description"]} |')
    lines += ['', '## فهرست سریع نقش‌ها', '', '| node | کار | نوع | مسئول |', '|---|---|---|---|']
    for f in graph['workflows']:
        for n in f['nodes']:
            lines.append(f'| [{n["id"]}]({f["id"]}.md#{n["id"].lower()}) | {n["title"]} | {n["actor"]} | {n["role"]} |')
    lines += ['', '## شروع‌های متداول', '',
              '- ایدهٔ تازه: I01 → I04 → P01؛ سپس محصول، QA، فنی، پیاده‌سازی و پذیرش.',
              '- تغییر رفتار: I01 → I04 → C01؛ نسخهٔ جاری حفظ و بخش متأثر باز می‌شود.',
              '- باگ با انتظار روشن: I01 → I04 → B01؛ گزارش کوتاه، QA regression، دریافت و بررسی فنی.',
              '- refactor بدون تغییر رفتار: I01 → I04 → T01 با baseline معتبر محصول و QA.',
              '- درخواست صرفاً طراحی مستندات: در handover مرحلهٔ خواسته‌شده با journal توقف ثبت می‌شود؛ ادامهٔ کد از این درخواست استنتاج نمی‌شود.',
              '', '[نمونه و تمرین مسیرها](../examples/otp-issue/README.md) · [قالب‌ها](../templates/README.md)', '']
    result['workflows/README.md'] = '\n'.join(lines)
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    graph = json.loads((ROOT/'workflows/graph.json').read_text())
    bad = []
    for name, content in documents(graph).items():
        path = ROOT/name
        if args.check:
            if not path.exists() or path.read_text() != content:
                bad.append(name)
        else:
            path.write_text(content)
    if bad:
        raise SystemExit('Generated cards differ: ' + ', '.join(bad))
    print('Workflow cards match graph.' if args.check else 'Workflow cards rendered.')

if __name__ == '__main__':
    main()
