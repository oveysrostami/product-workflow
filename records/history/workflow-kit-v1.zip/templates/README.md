# راهنمای ساخت پرونده از قالب‌ها

قالب‌ها قرارداد محتوا هستند، نه سند آمادهٔ تأیید. آن‌ها را فقط متناسب با applicability به پرونده کپی کنید و لینک‌های نسبی را برای محل جدید اصلاح کنید. هر placeholder با تصمیم واقعی یا N/A مستدل جایگزین شود؛ open item مؤثر به‌صراحت blocking بماند.

## شروع دستی

1. `requests/<request-id>/` بسازید؛ request، decisions، applicability و traceability را از shared بردارید.
2. مصاحبه اگر سؤال لازم است؛ impact اگر baseline تغییر می‌کند؛ review، manifest، approval و receipt به ازای هر تحویل. این‌ها تاریخچه append-only دارند.
3. برای محصول contract، عملیات/UC و acceptance را تکمیل کنید؛ flows/data متناسب. product handover از قالب کامل shared ساخته شود.
4. QA plan/scenarios/coverage را تکمیل و پس از approval تحویل فنی دهید. execution فقط پس از candidate پر می‌شود.
5. فنی اسناد canonical Backend و index/hash آن‌ها را تهیه می‌کند؛ توسعه task و delivery دارد. release صرفاً در صورت scope انتشار.

## فهرست قالب‌ها

| مشترک | کاربرد |
|---|---|
| [request](shared/request.md) | مسئله، stakeholder، نقش، scope و routing |
| [decisions](shared/decisions.md) | منشأ تصمیم و موارد باز |
| [interview](shared/interview.md) | متن batch و پاسخ، بدون تکرار سؤال |
| [applicability](shared/applicability.md) | مدارک لازم/نامرتبط با دلیل |
| [change-impact](shared/change-impact.md) | affected IDs و stale approval/evidence |
| [review](shared/review.md) | یافته با شاهد و مسیر اصلاح |
| [handover کامل](shared/handover.md) | قرارداد فرستنده/گیرنده و نسخه |
| [manifest](shared/manifest.json) | فایل/مخزن/revision/hash؛ بدون self-hash |
| [approval](shared/approval.json) | تصمیم انسان روی manifest مشخص |
| [receipt](shared/receipt.json) | اعلام دریافت واقعی، جدا از approval |
| [node-run](shared/node-run.json) | checkpoint هر node و ادامه پس از وقفه |
| [traceability](shared/traceability.csv) | ردیابی چندبه‌چند از rule تا evidence |

| مرحله | قالب‌ها |
|---|---|
| محصول | [contract](product/contract.md)، [flows/data](product/flows-and-data.md)، [operations/UC](product/operations-and-use-cases.md)، [acceptance](product/acceptance.md)، [handover](product/handover.md) |
| QA | [plan](qa/plan.md)، [scenarios](qa/scenarios.md)، [coverage](qa/coverage.md)، [execution](qa/execution.md)، [bug](qa/bug.md)، [handover](qa/handover.md) |
| فنی | [index](technical/index.md)، [module/domain](technical/module-and-domain.md)، [operation](technical/operation.md)، [data/migration](technical/data-and-migration.md)، [communication/delivery](technical/communication-and-delivery.md)، [runtime/recording](technical/runtime-and-recording.md)، [implementation plan](technical/implementation-plan.md)، [handover](technical/handover.md) |
| توسعه | [task](development/task.md)، [delivery](development/delivery.md)، [release](development/release.md)؛ review و execution از قالب مشترک و QA |

## تکمیل JSONهای ثبت

قالب‌ها عمداً pending و دارای placeholder هستند. approval تنها پس از پاسخ واقعی شامل decision با `role`، `identity`، `decision`، `reference`، `text` و `at` می‌شود؛ زمان نامعلوم null است. نقش G-P باید با درخواست‌کننده request یکسان باشد. تصمیم‌های G-T/G-D چندنقشی می‌توانند در یک فایل یا فایل‌های مستقل روی digest یکسان ثبت شوند؛ approved فقط پس از همه requiredRoles.

receipt شامل identity/role گیرنده، تصمیم accepted/returned، decisionReference، زمان واقعی و علت رد است. دریافت AI در D01 دریافت agent است؛ با دریافت انسانی QA/Tech اشتباه نشود.

manifest parentها را به digest immutable وصل می‌کند؛ approval و receipt جزو artifacts همان manifest نیستند. `openBlockers: []` فقط بعد بررسی واقعی خالی می‌ماند. JSON معتبر به‌تنهایی معنای workflow را validate نمی‌کند؛ gateها مسئول بررسی authority، scope و evidence‌اند.

در `traceability.csv` برای روابط چندبه‌چند چند ردیف بسازید؛ شناسه‌ها را با ویرگول در یک خانه انباشته نکنید. در طراحی status برابر planned و evidence خالی است. هنگام اجرا pass/fail/blocked/not-run و reference واقعی اضافه می‌شود.
