# بستهٔ طراحی فنی

> قالب است؛ `{{...}}` را با تصمیم و شاهد واقعیِ غیرحساس جایگزین کنید. وجود این فایل به معنی approval یا اجرای تست نیست.

- request / Tech lead / P-Q baseline و digest: {{...}}
- Backend revision، adopted edition/profile، local decisions: {{...}}
- workflow اصلی Backend و workflowهای وابسته: {{...}}
- discovery commandها و نتیجه واقعی doctor/explain: {{...}}

## مرجع canonical

| TECH-ID | موضوع | مسیر نهایی در Backend | revision/hash | draft در این پرونده یا canonical | rule/QA مرتبط |
|---|---|---|---|---|---|
| {{TECH-01}} | {{...}} | {{modules/owner/docs/...}} | {{...}} | {{...}} | {{...}} |

در زمان freeze دو فایل editable مرجع برای یک تصمیم وجود نداشته باشد. قالب‌های Backend شامل module-spec، context-map، domain-model، use-case-spec، dto-contract، communication-contract، recording-policy، acceptance-record و ADR در [_doc/templates](../../../backend/_doc/templates/README.md) هستند. این فرم‌ها اطلاعات handover را به آن قراردادها وصل می‌کنند، جایگزین قواعد دقیق آن‌ها نیستند.

## قابلیت لازم در برابر موجود

| capability | نیاز RULE/QA | implemented/optional/reference/unavailable | شاهد source/test | gap و task | اثر بر gate |
|---|---|---|---|---|---|
| {{...}} | {{...}} | {{...}} | {{...}} | {{...}} | {{...}} |

## تصمیم‌ها و ریسک‌ها

{{ADRها و alternatives با دلیل، اثر compatibility، انتخاب‌های انسانی لازم، موارد برگشتی به محصول و testability QA}}.

## نقشهٔ اسناد

module-and-domain، operation برای تک‌تک عملیات، data-and-migration، communication-and-delivery، runtime-and-recording و implementation-plan را طبق applicability تکمیل یا به سند canonical لینک کنید. N/A و دلیل در index بماند.
