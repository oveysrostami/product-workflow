# بستهٔ کار توسعه‌دهندهٔ AI

> قالب است؛ `{{...}}` را با تصمیم و شاهد واقعیِ غیرحساس جایگزین کنید. وجود این فایل به معنی approval یا اجرای تست نیست.

- TASK-ID / request / slice / assigned agent: {{...}}
- input baselines P/Q/T و digest / approval / implementation authorization: {{...}}
- checkout/base revision و dirty/diff snapshot: {{...}}
- prerequisite tasks و status: {{...}}

## ورودی لازم به ترتیب

{{AGENTS/handbook/owner docs، rule/UC/AC/QA، TECH operation و backend workflow}}.

## کار و مرز

{{تغییر دقیق در هر owner/layer/file، public contract/data/API و non-goal}}. فایل‌های خارج اختیار: {{...}}. componentهایی که لازم نیستند: {{...}}.

## ترتیب و evidence

| گام | خروجی | command/test | شرط پایان | نتیجه واقعی/report |
|---|---|---|---|---|
| preflight | {{...}} | {{...}} | {{...}} | {{not-run}} |
| domain/application | {{...}} | {{...}} | {{...}} | {{not-run}} |
| adapter/storage | {{...}} | {{...}} | {{...}} | {{not-run}} |
| entrypoint/composition | {{...}} | {{...}} | {{...}} | {{not-run}} |
| verify/review packet | {{...}} | {{...}} | {{...}} | {{not-run}} |

## توقف و ادامه

ابهام رفتار → C01، نقص طرح → T04، محیط غایب → blocked همان node، fail → لایه مالک، input stale → impact. checkpoint، output paths و nextNode: {{...}}. success stub، mock-only durability و waiver عمومی ممنوع.
