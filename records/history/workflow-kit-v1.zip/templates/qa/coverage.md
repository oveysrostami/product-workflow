# پوشش و testability

> قالب است؛ `{{...}}` را با تصمیم و شاهد واقعیِ غیرحساس جایگزین کنید. وجود این فایل به معنی approval یا اجرای تست نیست.

| RULE/AC | UC | QA scenarioها | happy/negative/boundary/race/recovery | gap یا N/A با دلیل | owner |
|---|---|---|---|---|---|
| {{...}} | {{...}} | {{...}} | {{...}} | {{...}} | {{...}} |

## QA → فنی → evidence

| QA-ID | TECH-ID/operation | suite/test path برنامه‌ریزی‌شده | seam/fixture/fault | observable oracle | environment | owner |
|---|---|---|---|---|---|---|
| {{...}} | {{...}} | {{...}} | {{...}} | {{...}} | {{...}} | {{...}} |

در مرحله QA ستون‌های فنی `pending-T05` هستند؛ G-Q این را gap oracle نمی‌داند. پیش از G-T mapping کامل می‌شود. در G-D شناسهٔ evidence واقعی به traceability اضافه می‌شود.

## بررسی دوطرفه

rule بدون QA: {{...}}؛ QA بدون منبع: {{...}}؛ تست فقط متکی به mock برای durability: {{...}}؛ scenarioهای فنی مستقل با source backend-rule: {{...}}. نامرتبط‌ها از شمار لازم کنار گذاشته می‌شوند، ولی دلیل و owner حفظ می‌شود.
