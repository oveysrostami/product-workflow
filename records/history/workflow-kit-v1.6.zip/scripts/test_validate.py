"""Regression checks for mutable request state and the frozen workflow kit."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class RequestStateValidationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='workflow-validator-test-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)/'kit'
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns('.git', '__pycache__'))

    def read_json(self, name):
        return json.loads((self.root/name).read_text())

    def write_json(self, name, data):
        (self.root/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')

    def validate(self):
        result = subprocess.run(
            [sys.executable, 'scripts/validate.py'], cwd=self.root,
            capture_output=True, text=True,
        )
        report = json.loads(result.stdout)
        self.assertEqual(result.returncode, 0 if report['status'] == 'passed' else 1)
        return report

    def add_draft_card(self):
        request_id = 'validator-fixture'
        request = self.root/'requests'/request_id
        request.mkdir()
        for name in ('request.md', 'tracking.md'):
            (request/name).write_text('# Synthetic validator fixture\n')
        card = self.read_json('templates/shared/board-card.json')
        card.update(
            requestId=request_id, title='Synthetic validator fixture',
            requestPath=f'requests/{request_id}/request.md',
            trackingPath=f'requests/{request_id}/tracking.md',
            authorizationReference='Temporary fixture; no real request or approval',
        )
        board = self.read_json('requests/board.json')
        board['cards'].append(card)
        self.write_json('requests/board.json', board)
        return board

    def test_new_card_and_valid_movement_preserve_design_baseline(self):
        frozen = (self.root/'records/design-manifest.json').read_bytes()
        board = self.add_draft_card()
        self.assertEqual(self.validate()['errors'], [])
        board['cards'][-1].update(
            state='product-draft', action='continue', currentNode='P01', nextNode='P02',
        )
        self.write_json('requests/board.json', board)
        self.assertEqual(self.validate()['errors'], [])
        self.assertEqual((self.root/'records/design-manifest.json').read_bytes(), frozen)

    def test_invalid_card_is_still_rejected(self):
        board = self.add_draft_card()
        board['cards'][-1]['state'] = 'invalid-state'
        self.write_json('requests/board.json', board)
        self.assertIn('Invalid board value: validator-fixture/state', self.validate()['errors'])

    def test_changed_design_document_is_still_rejected(self):
        document = self.root/'docs/01-principles-and-roles.md'
        document.write_text(document.read_text()+'\nSynthetic unversioned change.\n')
        self.assertIn(
            'Design baseline changed: docs/01-principles-and-roles.md',
            self.validate()['errors'],
        )

    def test_operational_board_cannot_be_frozen_again(self):
        manifest = self.read_json('records/design-manifest.json')
        manifest['artifacts'].append({
            'path': 'requests/board.json',
            'sha256': hashlib.sha256((self.root/'requests/board.json').read_bytes()).hexdigest(),
        })
        self.write_json('records/design-manifest.json', manifest)
        approval = self.read_json('records/design-approval.json')
        approval['manifestSha256'] = hashlib.sha256(
            (self.root/'records/design-manifest.json').read_bytes(),
        ).hexdigest()
        self.write_json('records/design-approval.json', approval)
        self.assertIn(
            'Operational request file in design baseline: requests/board.json',
            self.validate()['errors'],
        )

    def test_operational_board_cannot_enter_static_inventory(self):
        inventory = self.read_json('research/source-inventory.json')
        inventory['files'].append({
            'repository': 'product-workflow', 'path': 'requests/board.json',
            'sha256': hashlib.sha256((self.root/'requests/board.json').read_bytes()).hexdigest(),
        })
        self.write_json('research/source-inventory.json', inventory)
        self.assertIn(
            'Operational request file in local source inventory: requests/board.json',
            self.validate()['errors'],
        )


if __name__ == '__main__':
    unittest.main()
