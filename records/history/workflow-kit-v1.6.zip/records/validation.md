# گزارش بررسی نسخهٔ ۱٫۶

تاریخ: ۲۰۲۶-۰۹-۲۸. اصلاح محدودهٔ برد عملیاتی و محل ثبت checkout بررسی شد؛ تصویب انسانی کل نسخه هنوز pending است. مقصد طراحی و پیاده‌سازی همان Backend است. این گزارش اجرای یک پروندهٔ واقعی یا اثبات کد Backend نیست.

## ساختار مجموعه

دستورهای بررسی از ریشهٔ مجموعه:

```sh
python3 scripts/render_workflows.py --check
python3 scripts/validate.py
python3 -m unittest discover -s scripts -p 'test_*.py'
```

تطابق کارت‌ها با graph و validator بدون خطا قبول شدند. مجموعه ۷۵ Markdown، ۵۸ node در ۸ workflow، ۲۷ دنبالهٔ تمرینی و ۸۳ منبع ثابت محلی دارد؛ برد واقعی همچنان صفر کارت دارد. آمار دقیق و خروجی validator در [checks](checks.json) است.

## regression برد عملیاتی

پیش از اصلاح، افزودن یک کارت draft معتبر در کپی مستقل تنها خطای `Design baseline changed: requests/board.json` را تولید کرد. علت، حضور وضعیت متغیر برد در manifest ثابت طراحی بود. در نسخهٔ تازه فایل‌های عملیاتی requests/ به‌جز README ثابت از manifest طراحی و inventory ثابت خارج‌اند؛ ساختار کارت‌ها و وجود مدارک همچنان بررسی می‌شوند.

هر پنج آزمون [regression](../scripts/test_validate.py) در کپی‌های موقت بدون .git قبول شدند:

1. افزودن کارت draft معتبر و سپس تغییر معتبر وضعیت آن، بدون تغییر bytes manifest طراحی، هر دو validator را پاس کردند.
2. کارت دارای state نامعتبر رد شد.
3. تغییر سند طراحی ثابت همچنان با خطای hash رد شد.
4. افزودن دوبارهٔ برد به manifest طراحی، حتی با hash درست و digest منطبق approval، رد شد.
5. افزودن برد به inventory ثابت، حتی با hash درست، رد شد.

تمام fixtureها ساختگی و موقت‌اند؛ هیچ کارت، approval یا receipt واقعی ایجاد نشده و برد اصلی تغییر نکرده است. این آزمون‌ها ساختار و جدایی state/design را می‌سنجند و صلاحیت gate انسانی یا معنای حرکت واقعی را اثبات نمی‌کنند.

## محل ثبت ورودی Backend

[قرارداد اتصال](../docs/05-backend-binding.md)، [قالب index فنی](../templates/technical/index.md) و T02 در graph/کارت تولیدشده هماهنگ‌اند: دریافت ورودی در T01؛ ثبت repository، checkout، revision و مسیر AGENTS/قواعد در `technical/index.md` همان پرونده توسط فنی. مالکیت محصول بر request.md حفظ شده و محل ثبت مبهم قبلی حذف شد. قواعد فناوری Backend تغییر نکردند.

## Mermaid

هر ۱۵ نمودار بدون تغییر است و hash متن همهٔ آن‌ها با [شاهد رندر نسخهٔ ۱٫۵](mermaid-evidence.json) منطبق بود. mermaid-cli در مسیر ثبت‌شده و PATH موجود نیست؛ **رندر مجدد Mermaid در این نوبت بررسی نشده است**. شاهد پیشین از رندر Mermaid 12.0.0 با Chrome headless حفظ شد؛ تطبیق hash جای اجرای تازهٔ parser یا بازرسی بصری را نمی‌گیرد.

## نسخه، مالکیت و حدود بررسی

نسخهٔ ۱٫۵، manifest و approvalِ pending آن در Git و [رکورد تاریخچه](history/workflow-kit-v1.5.json) محفوظ‌اند. نسخهٔ ۱٫۶ manifest و approvalِ pending مستقل دارد؛ اختیار این دو اصلاح از دستور کاربر ثبت شد.

تیم فعال نگهداری workflow و محدودهٔ نوشتن در [ثبت طراحی](design-review.md) آمده‌اند؛ diff با همان محدوده بررسی شد. هیچ فایل پروندهٔ واقعی یا Backend تغییر نکرد و هیچ merge، deploy یا تست Backend اجرا نشد. بررسی این اصلاح self-review است؛ independent review یا تصویب کامل نسخه ادعا نمی‌شود.
