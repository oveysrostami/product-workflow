# گزارش بررسی نسخهٔ ۱٫۷

تاریخ: ۲۰۲۶-۰۹-۲۸. کتابخانهٔ ماژول‌ها و اتصال آن به تأیید فنی بررسی شد؛ تصویب انسانی کل نسخه هنوز pending است. مقصد طراحی و پیاده‌سازی همان Backend است. این گزارش اجرای پروندهٔ واقعی یا اثبات کد Backend نیست.

## ساختار مجموعه

دستورهای بررسی از ریشهٔ مجموعه:

```sh
python3 scripts/render_workflows.py --check
python3 scripts/validate.py
python3 -m unittest discover -s scripts -p 'test_*.py'
```

تطابق کارت‌ها با graph و validator بدون خطا قبول شدند. مجموعه ۷۸ Markdown، ۵۹ node در ۸ workflow، ۲۷ دنبالهٔ تمرینی و ۸۹ منبع ثابت محلی دارد؛ برد واقعی صفر کارت و کتابخانه صفر ماژول منتشرشده دارد. آمار دقیق و خروجی validator در [checks](checks.json) است.

## کتابخانهٔ ماژول‌ها

[قرارداد کتابخانه](../docs/10-module-library.md)، [قالب کامل ماژول](../templates/modules/README.md)، مالکیت فایل‌ها و مسیر فنی هماهنگ‌اند. T04 snapshot تجمعی را در پرونده تهیه می‌کند؛ T05/T06 آن را review می‌کنند؛ T07 همان plan و bytes را تأیید می‌کند؛ T09 پیش از تحویل T08 نسخهٔ مصوب را در modules منتشر می‌کند. تأیید طرح، اختیار پیاده‌سازی نیست.

ابزار [انتشار](../scripts/publish_module.py) پیش‌فرض preview است. apply نسخهٔ immutable، ورودی خواندن و pointer را فقط پس از کنترل G-T ثبت‌شده، hash تمام محتوا و baseRevision می‌نویسد. wrapper پس از approval ساخته می‌شود تا چرخهٔ hash ایجاد نشود. تغییر base به T02 برمی‌گردد. ابزار authority انسانی و درستی معنایی تمام شرح ماژول را اثبات نمی‌کند؛ review/gate همچنان لازم است.

metadata پیاده‌سازی از طرح جداست و به designRevision/digest و source revision واقعی متصل می‌شود. V06 و R07 شواهد پذیرش و انتشار را برای ثبت Coordinator فراهم می‌کنند. اجرای طرح قدیمی به‌عنوان اجرای طرح جاری معرفی نمی‌شود. اسناد کنار کد Backend و قواعد DDD آن حفظ شده‌اند.

## regression

هر ۱۲ آزمون [regression](../scripts/test_validate.py) در کپی‌های موقت بدون .git قبول شدند:

- پنج آزمون جدایی وضعیت جاری از طراحی: افزودن/حرکت معتبر کارت، رد state نامعتبر، تشخیص تغییر سند ثابت و رد برد عملیاتی در manifest و inventory ثابت.
- هفت آزمون ماژول: preview و انتشار و retry؛ رد approvalِ pending؛ جلوگیری از نوشتن از طریق مقصد symlink؛ رد تغییر bytes پس از approval؛ حفظ نسخهٔ قبلی و رد base منقضی؛ تشخیص دستکاری نسخهٔ منتشرشده؛ رد ادعای پذیرش پیاده‌سازی بدون source revision.

تمام fixtureها، تصمیم‌ها و شناسه‌های آزمون ساختگی و فقط در کپی موقت‌اند؛ هیچ کارت، approval، receipt یا ماژول واقعی ایجاد نشده و برد اصلی تغییر نکرده است. این آزمون‌ها ساختار و کنترل انتشار را می‌سنجند، نه صلاحیت انسان یا اجرای Backend.

## محل ثبت ورودی Backend

اصلاح نسخهٔ ۱٫۶ حفظ شد: دریافت ورودی در T01 و ثبت repository، checkout، revision و مسیر قواعد در technical/index.md همان پرونده توسط فنی. request.md محصول فقط خواندنی است؛ قواعد فناوری Backend تغییر نکردند.

## Mermaid

همهٔ ۱۵ نمودار فعلی با Mermaid CLI 12.0.0، Node 22.22.0 و Google Chrome headless دوباره parse و به SVG رندر شدند. [شاهد رندر](mermaid-evidence.json) hash متن هر نمودار و فرمان/خروجی واقعی را نگه می‌دارد. بازرسی بصری تک‌تک نمودارها ادعا نمی‌شود. renderer در مسیر موقت نصب شد؛ dependency پروژه تغییر نکرد.

## نسخه، مالکیت و حدود بررسی

نسخهٔ ۱٫۵ در Git و [رکورد تاریخچه](history/workflow-kit-v1.5.json) محفوظ است. bytes دقیق نسخهٔ commitنشدهٔ ۱٫۶، manifest و approvalِ pending آن در [آرشیو](history/workflow-kit-v1.6.zip) و [رکورد hash](history/workflow-kit-v1.6.json) حفظ شدند؛ hash آرشیو و تمام artifacts آن دوباره بررسی و منطبق شدند. نسخهٔ ۱٫۷ manifest و approvalِ pending مستقل دارد؛ اختیار تغییر و انتخاب «آخرین طرح تأییدشده همراه وضعیت پیاده‌سازی» از کاربر ثبت شده است.

تیم فعال نگهداری workflow و محدودهٔ نوشتن در [ثبت طراحی](design-review.md) آمده‌اند؛ diff با همان محدوده بررسی و git diff --check بدون خطا اجرا شد. هیچ فایل پروندهٔ واقعی یا Backend تغییر نکرد و هیچ merge، deploy یا تست Backend اجرا نشد. بررسی این اصلاح self-review است؛ independent review یا تصویب کامل نسخه ادعا نمی‌شود.
