# تحویل technical به توسعه‌دهنده AI

> قالب است؛ `{{...}}` را با تصمیم و شاهد واقعیِ غیرحساس جایگزین کنید. وجود این فایل به معنی approval یا اجرای تست نیست.

از [قالب کامل handover](../shared/handover.md) استفاده و آن را در پرونده تکمیل کنید. فیلدهای زیر برای این مرحله الزامی‌اند:

- بسته و parent baselineهای دقیق با manifest/digest و approval خارج manifest.
- canonical Backend specs، task dependency، file/layer map، commands و migration/recovery.
- read order و لینک canonical هر سند؛ در پرونده لینک‌ها نسبت به محل جدید بازنویسی شوند.
- انتظار از توسعه‌دهنده AI، owner مسئول دریافت و معیار پذیرش ورودی.
- open itemها با اثر و owner؛ blocker جاری نباید زیر عبارت «بعداً» پنهان شود.
- receipt جدا با وضعیت pending تا اعلام واقعی دریافت.

این فایل راهنمای انتخاب است؛ در پروندهٔ واقعی باید **تمام متن قالب کامل** با محتوای مرحله جایگزین شود، نه اینکه صرفاً همین پنج خط تحویل شوند.


بسته باید impact-map، cross-module-flows، index همه change-spec/test-mappingهای ماژولی، نتیجهٔ review مسئولان ماژول و جمع‌بندی کل درخواست را داشته باشد. ترتیب dependency و مسیر task هر ماژول، taskهای مشترک و مسئول integration، QAهای محلی/مشترک و وضعیت readiness مشخص باشند. handover مستقل برای هر ماژول الزام نیست؛ یک تحویل یکپارچهٔ قابل ردیابی کافی است.
